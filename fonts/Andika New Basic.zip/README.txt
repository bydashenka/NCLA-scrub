Andika New Basic is a limited-character-set (no extended IPA or Cyrillic) version of [Andika](https://fonts.google.com/specimen/Andika?query=Andi) that includes Regular, Bold, Italic and Bold-Italic faces.

Andika New Basic supports Latin and Latin-1 Supplement Unicode ranges, plus a selection of the more commonly used extended Latin characters, with miscellaneous diacritical marks, symbols and punctuation.

Read more at [software.sil.org/andika](https://software.sil.org/andika/)